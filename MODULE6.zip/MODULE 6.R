install.packages("keras")
library(keras)

# Load dataset
fashion_mnist <- dataset_fashion_mnist()
x_train <- fashion_mnist$train$x / 255
y_train <- fashion_mnist$train$y
x_test <- fashion_mnist$test$x / 255
y_test <- fashion_mnist$test$y

# Reshape
x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1))
x_test <- array_reshape(x_test, c(nrow(x_test), 28, 28, 1))

# Build model
model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3,3), activation = "relu",
                input_shape = c(28,28,1)) %>%
  layer_max_pooling_2d(pool_size = c(2,2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2,2)) %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = "relu") %>%
  layer_dense(units = 10, activation = "softmax")

# Compile
model %>% compile(
  optimizer = "adam",
  loss = "sparse_categorical_crossentropy",
  metrics = "accuracy"
)

# Train
model %>% fit(x_train, y_train, epochs = 5,
              validation_data = list(x_test, y_test))

# Evaluate
model %>% evaluate(x_test, y_test)
predictions <- model %>% predict(x_test[1:2,,,drop=FALSE])
predicted_classes <- apply(predictions, 1, which.max) - 1

print(predicted_classes)
print(y_test[1:2])